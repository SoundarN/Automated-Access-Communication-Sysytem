-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2024 at 06:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(1, 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `announce`
--

CREATE TABLE `announce` (
  `id` int(20) NOT NULL,
  `today_date` varchar(20) NOT NULL,
  `announcement_date` varchar(20) NOT NULL,
  `meeting_about` varchar(20) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `employee_name` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announce`
--

INSERT INTO `announce` (`id`, `today_date`, `announcement_date`, `meeting_about`, `dept`, `employee_name`, `status`) VALUES
(1, 'None', '2024-09-25', '11:30 AM', 'Technical Team Proce', 'Soundar', 'Accepted'),
(4, 'None', '2024-09-25', '11:30 AM', 'Technical Team Proce', '2', 'New'),
(5, 'None', '2024-09-25', '11:30 AM', 'Technical Team Proce', '2', 'New'),
(6, 'None', '2024-09-25', '11:30 AM', 'Technical Team Proce', '2', 'New'),
(7, 'None', '2024-09-25', '11:30 AM', 'Technical Team Proce', 'Soundar', 'New'),
(8, 'None', '2024-09-25', '11:30 AM', 'Technical Team Proce', 'Soundar', 'New'),
(9, 'None', '2024-09-25', '11:30 AM', 'Technical Team Proce', 'Soundar', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `announcement_date` varchar(20) NOT NULL,
  `meeting_date` varchar(20) NOT NULL,
  `meeting_time` varchar(20) NOT NULL,
  `meeting_about` varchar(50) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `meeting_area` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `date`, `announcement_date`, `meeting_date`, `meeting_time`, `meeting_about`, `dept`, `meeting_area`, `status`) VALUES
(1, '24-09-2024', '2024-09-25', '2024-09-30', '11:30 AM', 'Technical Team Process', 'all', 'Hall 1', 'Accepted'),
(2, '24-09-2024', '2024-09-27', '2024-10-07', '11:30 AM', 'Financial Meeting', 'financial', 'Hall 4', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(20) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `customer_address` varchar(100) NOT NULL,
  `customer_mail` varchar(30) NOT NULL,
  `customer_number` varchar(10) NOT NULL,
  `project_idea` varchar(100) NOT NULL,
  `estimated_amount` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `customer_name`, `customer_address`, `customer_mail`, `customer_number`, `project_idea`, `estimated_amount`) VALUES
(1, 'sethu', 'saibaba colony', 'sethu@gmail.com', '7372654890', 'admin login', '45k');

-- --------------------------------------------------------

--
-- Table structure for table `employeeform`
--

CREATE TABLE `employeeform` (
  `id` int(10) NOT NULL,
  `firstname` varchar(10) DEFAULT NULL,
  `lastname` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `phonenumber` bigint(10) DEFAULT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `qualified` varchar(10) DEFAULT NULL,
  `street` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `experience` varchar(10) DEFAULT NULL,
  `salary` int(10) DEFAULT NULL,
  `pincode` int(10) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `profile` varchar(70) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employeeform`
--

INSERT INTO `employeeform` (`id`, `firstname`, `lastname`, `email`, `password`, `gender`, `phonenumber`, `dob`, `qualified`, `street`, `city`, `state`, `country`, `experience`, `salary`, `pincode`, `dept`, `profile`, `status`) VALUES
(2, 'Soundar', 'N', 'soundar.nsd@gmail.com', 'EMP003', 'Male', 9342542431, '2003-08-19', 'B.TECH', 'Builders engineering', 'Tripur', 'Tamil Nadu', 'India', '3', 48000, 638108, 'technical', 'WhatsApp Image 2024-10-13 at 10.44.13 AM.jpeg', 'generated'),
(3, 'Mathi', 'P', 'mathi2725@gmail.com', 'EMP004', 'Male', 9566312904, '2002-12-24', 'B.COM', 'Murali', 'Anthiyur', 'Tamil Nadu', 'India', '3', 460000, 638108, 'marketing', 'dog3.jpg', 'generated'),
(4, 'abi', 'j', 'abinaya191@gmail.com', '7080', 'Female', 8778517880, '2004-08-19', 'BE', 'venganur', 'attur', 'tamilnadu', 'india', '3', 40000, 638311, 'Financial', 'dog2.jpeg', 'generated'),
(5, 'aadhavan', 'k', 'adhavan97@gmail.com', 'EMP006', 'Male', 9688629977, '1997-12-04', 'B.COM', 'bhoothapadi', 'bahvani', 'Tamil Nadu', 'India', '5', 50000, 638108, 'Financial', 'proj3 bg.jpg', 'generated'),
(6, 'Abinaya', 'J', 'nayaa8916@gmail.com', 'EMP007', 'Female', 8778517880, '2004-08-19', 'BE', 'venganur', 'Salem', 'Tamil Nadu', 'India', '2', 45000, 638311, 'Financial', 'proj3 bg.jpg', 'generated'),
(7, 'yamuna', 's', 'yamunas23920021@gmail.com', 'EMP008', 'Female', 9874563210, '2001-05-12', 'B.TECH', 'saibaba colony', 'covai', 'Tamilnadu', 'India', '2', 45000, 638108, 'technical', 'ben 6.jpg', 'generated'),
(8, 'Aakash', 'A', 'aakash@gmail.com', 'EMP009', 'Male', 8529631470, '2000-05-12', 'B.TECH', 'students colony', 'madurai', 'Tamilnadu', 'India', '2', 35000, 638501, 'technical', 'ben 11.jpg', 'generated'),
(9, 'lingesh', 'r', 'ramlingesh@gmail.com', '', 'Male', 9876543210, '2004-05-17', 'B.TECH', 'vellakovil', 'kangeyam', 'Tamilnadu', 'India', '1', 30000, 638301, 'technical', 'ben 7.jpg', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `hrregform`
--

CREATE TABLE `hrregform` (
  `id` int(10) NOT NULL,
  `firstname` varchar(10) DEFAULT NULL,
  `lastname` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `passwrd` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `pnumber` bigint(10) DEFAULT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `qualified` varchar(10) DEFAULT NULL,
  `street` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `experience` varchar(10) DEFAULT NULL,
  `salary` int(10) DEFAULT NULL,
  `pincode` int(10) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `profile` varchar(70) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hrregform`
--

INSERT INTO `hrregform` (`id`, `firstname`, `lastname`, `email`, `passwrd`, `gender`, `pnumber`, `dob`, `qualified`, `street`, `city`, `state`, `country`, `experience`, `salary`, `pincode`, `dept`, `profile`, `status`) VALUES
(1, 'Babu', 'B', 'babu19@gmail.com', 'EMP002', 'Male', 7378965412, '2000-06-25', 'M.TECH', 'saibaba colony', 'covai', 'Tamil Nadu', 'India', '4', 50000, 638108, 'HR', 'pjt 1.webp', 'generated'),
(2, 'Prithima', 'P', 'prithima@gmail.com', 'EMP003', 'Female', 9876543210, '1997-05-19', 'B.TECH', 'saibaba colony', 'Dindugal', 'Tamilnadu', 'India', '5', 75000, 638505, 'HR', 'ben26.jpg', 'generated'),
(3, 'Ashwin', 'A', 'ashwin@gmail.com', NULL, 'Male', 7373986540, '2004-05-15', 'B.COM', 'Kolathur', 'Mettur', 'Tamilnadu', 'India', '2', 35000, 638309, 'HR', 'ben26.jpg', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(20) NOT NULL,
  `company_name` varchar(20) NOT NULL,
  `company_address` varchar(100) NOT NULL,
  `company_email` varchar(50) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `invoice_no` varchar(20) NOT NULL,
  `issue_date` varchar(20) NOT NULL,
  `deadline_date` varchar(20) NOT NULL,
  `total_payment` varchar(20) NOT NULL,
  `customer_name` varchar(20) NOT NULL,
  `customer_address` varchar(100) NOT NULL,
  `customer_number` varchar(10) NOT NULL,
  `customer_email` varchar(50) NOT NULL,
  `project_name` varchar(30) NOT NULL,
  `project_details` varchar(100) NOT NULL,
  `profile` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `employee_name` varchar(11) NOT NULL,
  `payment_process` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `company_name`, `company_address`, `company_email`, `phone_number`, `invoice_no`, `issue_date`, `deadline_date`, `total_payment`, `customer_name`, `customer_address`, `customer_number`, `customer_email`, `project_name`, `project_details`, `profile`, `status`, `employee_name`, `payment_process`) VALUES
(1, 'Techvolt', 'saibaba colony', 'techvolt@gmail.com', '9876543210', '25', '21-09-2024', '20-12-2024', '10 k', 'sethu', 'teachers colony', '7373657555', 'sethu@gmail.com', 'admin login', 'login type', 'proj3 bg.jpg', 'Accepted', 'Soundar', 'paid'),
(2, 'cts', 'covai', 'cts@gmail.com', '8796541230', '23', '21-09-2024', '15-12-2024', '5k', 'saran', 'erode', '7845129630', 'saran@gmail.com', 'virtual mouse', 'hand gecture virtual', 'proj2 bg.jpeg', 'New', '0', 'unpaid'),
(3, 'Tcs', 'covai', 'aakash@gmail.com', '7373986540', '23', '21-09-2024', '25-10-2024', '10 k', 'sethu', 'teachers colony', '7373657555', 'sethu@gmail.com', 'admin login', 'login type', 'proj1 bg.jpeg', 'Accepted', 'Soundar', '0'),
(5, 'zoho', 'chennai', 'zoho@gmail.com', '7373986540', '21', '23-09-2024', '20-02-2025', '20k', 'Vidhyasakar', 'erode', '7373657555', 'vidhaya123@gmail.com', 'Taskmonitor', 'track the things', 'ben 11.jpg', 'Accepted', 'Yamuna', '0'),
(6, 'Redhat', 'covai', 'redhat@gmail.com', '9988776655', '55', '07-10-2024', '01-12-2024', '25k', 'kumar', 'erode', '9865423170', 'kumar123@gmail.com', 'virtualmouse', 'hand gecture mouse', 'prj 2.jpg', 'New', '', 'paid'),
(7, 'Red Hat', 'Builders engineering college', 'chinuselvi45@gmail.com', '0934254243', '55', '07-10-2024', '01-12-2024', '25k', 'kumar', 'erode', '9865423170', 'kumar123@gmail.com', 'virtualmouse', 'hand gecture mouse', 'proj3 bg.jpg', 'New', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jobleave`
--

CREATE TABLE `jobleave` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `dept` varchar(30) NOT NULL,
  `date` varchar(20) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobleave`
--

INSERT INTO `jobleave` (`id`, `name`, `dept`, `date`, `reason`, `status`) VALUES
(1, 'soundar', 'Technical', '2024-10-15', 'Health Issues', 'Accepted'),
(2, 'Mathi', 'Marketing', '2024-10-15', 'Health Issues', 'Rejected'),
(3, 'soundar', 'Marketing', '2024-10-08', 'Health Issues', 'Accepted'),
(4, 'Mathi', 'Marketing', '2024-10-09', 'Health Issues', ''),
(5, 'Babu', 'HR', '2024-10-24', 'Own Problems', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `job_acceptance`
--

CREATE TABLE `job_acceptance` (
  `id` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `usermail` varchar(50) NOT NULL,
  `position` varchar(30) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `salary` varchar(20) NOT NULL,
  `experience` varchar(20) NOT NULL,
  `requirements` varchar(100) NOT NULL,
  `hrname` varchar(30) NOT NULL,
  `hrmail` varchar(50) NOT NULL,
  `suggestion` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `package` varchar(50) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `status2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_acceptance`
--

INSERT INTO `job_acceptance` (`id`, `username`, `usermail`, `position`, `qualification`, `salary`, `experience`, `requirements`, `hrname`, `hrmail`, `suggestion`, `status`, `package`, `destination`, `status2`) VALUES
(1, 'Soundar ', 'soundar.nsd@gmail.com', 'Technical Hacker', 'B.TECH', '2 years', '45K', 'None', 'Babu', 'babu19@gmail.com', 'Congrats', 'Rejected', '50k', 'technical work', 'Rejected'),
(2, 'Soundar ', 'nayaa8916@gmail.com', 'Technical Hacker', 'B.TECH', '2 years', '45K', 'None', 'Babu', 'babu19@gmail.com', 'Good', 'Accepted', '45k', 'Hacking team', 'Accepted'),
(3, 'Soundar ', 'chinu19soundar@gmail.com', 'Testing team', 'B.E', '2 years', '40k', ' reviewing candidates', 'Babu', 'babu19@gmail.com', 'Welldone', 'Accepted', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `job_vacancy`
--

CREATE TABLE `job_vacancy` (
  `id` int(20) NOT NULL,
  `position` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `experience` varchar(20) NOT NULL,
  `salary` varchar(20) NOT NULL,
  `requirements` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_vacancy`
--

INSERT INTO `job_vacancy` (`id`, `position`, `qualification`, `experience`, `salary`, `requirements`) VALUES
(1, 'Technical Hacker', 'B.TECH', '2 years', '45K', 'None'),
(2, 'Technical Hacker', 'B.TECH', '2 years', '45K', 'all requirements'),
(5, 'Testing team', 'B.E', '2 years', '40k', ' reviewing candidates'),
(6, 'Development Role', 'M.E', '3 years', '50k', 'Project Management');

-- --------------------------------------------------------

--
-- Table structure for table `leaveform`
--

CREATE TABLE `leaveform` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(70) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `startdate` varchar(20) NOT NULL,
  `enddate` varchar(20) NOT NULL,
  `reason` varchar(20) NOT NULL,
  `no_of_days` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leaveform`
--

INSERT INTO `leaveform` (`id`, `name`, `email`, `dept`, `date`, `startdate`, `enddate`, `reason`, `no_of_days`, `status`) VALUES
(2, 'yamuna', 'yamunas23920021@gmail.com', 'technical', '17-09-2024', '2024-09-26', '2024-09-29', 'personal', '3', 'Accepted'),
(3, 'Babu', 'soundar.nsd@gmail.com', 'HR', '18-09-2024', '2024-09-27', '2024-09-30', 'medical checkup', '3', 'Rejected'),
(4, 'Prithima', 'prithima@gmail.com', 'HR', '18-09-2024', '2024-09-19', '2024-09-24', 'personal', '5', 'Accepted'),
(5, 'Mathi', 'mathi2725@', 'marketing', '19-09-2024', '2024-09-30', '2024-10-08', 'personal', '8', 'Accepted'),
(6, 'abi', 'abinaya191', 'Financial', '19-09-2024', '2024-09-23', '2024-09-27', 'medical checkup', '4', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(20) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `customer_mail` varchar(50) NOT NULL,
  `project_name` varchar(30) NOT NULL,
  `documents` varchar(60) NOT NULL,
  `date` varchar(20) NOT NULL,
  `enddate` varchar(20) NOT NULL,
  `employee_name` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `employee_mail` varchar(50) NOT NULL,
  `hrmail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `customer_name`, `customer_mail`, `project_name`, `documents`, `date`, `enddate`, `employee_name`, `status`, `employee_mail`, `hrmail`) VALUES
(1, 'sethu', 'soundar.nsd@gmail.com', 'admin login', 'proj3 bg.jpg', '21-09-2024', '20-12-2024', 'Soundar', 'Accepted', 'soundar.nsd@gmail.com', ''),
(2, 'saran', 'saran@gmail.com', 'virtual mouse', 'proj2 bg.jpeg', '21-09-2024', '20-1-2025', 'Soundar', 'Accepted', 'None', ''),
(3, 'saran', 'saran@gmail.com', 'virtual mouse', 'proj2 bg.jpeg', '21-09-2024', 'None', '0', 'Accepted', 'soundar.nsd@gmail.com', ''),
(4, 'sethu', 'sethu@gmail.com', 'admin login', 'proj3 bg.jpg', '21-09-2024', '20-12-2024', '0', 'New', '', ''),
(5, 'Vidhyasakar', 'vidhaya123@gmail.com', 'Taskmonitor', 'ben 11.jpg', '23-09-2024', '20-02-2025', 'Soundar', 'Accepted', 'soundar.nsd@gmail.com', 'babu19@gmail.com'),
(6, 'Vidhyasakar', 'vidhaya123@gmail.com', 'Taskmonitor', 'ben 11.jpg', '23-09-2024', '20-02-2025', 'Yamuna', 'New', '', 'babu19@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `quotation`
--

CREATE TABLE `quotation` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `location` varchar(20) NOT NULL,
  `project_name` varchar(150) NOT NULL,
  `project_value` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `project_type` varchar(70) NOT NULL,
  `documents` varchar(250) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quotation`
--

INSERT INTO `quotation` (`id`, `name`, `email`, `company_name`, `location`, `project_name`, `project_value`, `date`, `project_type`, `documents`, `status`) VALUES
(3, 'Soundar N', 'chinuselvi45@gmail.com', 'Red Hat', 'covai', 'adminlogin', '3lks', '2 months', 'Login Type', 'GE3791                   HUMAN VALUES AND ETHICSL T P C.docx', 'Accepted'),
(4, 'sasi', 'sasi@gmail.com', 'Red Hat', 'erode', 'virtualmouse', '25k', '3months', 'hand move', 'ben 11.jpg', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phonenumber` varchar(10) NOT NULL,
  `qualification` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `experience` varchar(20) NOT NULL,
  `salary_exp` varchar(20) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `profile` varchar(20) NOT NULL,
  `salary` varchar(20) NOT NULL,
  `leavedays` varchar(20) NOT NULL,
  `salarydate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `firstname`, `email`, `phonenumber`, `qualification`, `city`, `experience`, `salary_exp`, `dept`, `profile`, `salary`, `leavedays`, `salarydate`) VALUES
(1, 'abi', 'abinaya191', '8778517880', 'BE', 'attur', '3', '40000', 'technical', 'proj3 bg.jpg', '80000', '35.0', '12-09-2024'),
(2, 'Soundar', 'chinuselvi', '9342542431', 'B.TECH', 'Tripur', '3', '48000', 'technical', 'proj1 bg.jpeg', '80000', '35.0', '12-09-2024'),
(3, 'soundhar', 'soundar.ns', '9342542431', 'B.TECH', 'Tripur', '3', '50000', 'technical', 'proj1 bg.jpeg', '80000', 'None', '12-09-2024'),
(4, 'Babu', 'babu19@gmail.com', '7378965412', 'M.TECH', 'covai', '4', '50000', 'HR', 'proj2 bg.jpeg', '80000', '9.0', '12-09-2024'),
(5, 'Babu', 'babu19@gmail.com', '7378965412', 'M.TECH', 'covai', '4', '50000', 'HR', 'proj2 bg.jpeg', '100000', '9.0', '12-09-2024'),
(6, 'Babu', 'babu19@gmail.com', '7378965412', 'M.TECH', 'covai', '4', '50000', 'HR', 'proj2 bg.jpeg', '100000', '9.0', '17-09-2024'),
(7, 'abi', 'abinaya191@gmail.com', '8778517880', 'BE', 'attur', '3', '40000', 'Financial', 'proj3 bg.jpg', '50000', '4.0', '19-09-2024'),
(8, 'Soundar', 'soundar.nsd@gmail.com', '9342542431', 'B.TECH', 'Tripur', '3', '48000', 'technical', 'proj1 bg.jpeg', '80000', 'None', '07-10-2024');

-- --------------------------------------------------------

--
-- Table structure for table `userdashboard`
--

CREATE TABLE `userdashboard` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phonenumber` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `language` varchar(20) NOT NULL,
  `skill` varchar(30) NOT NULL,
  `profile` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userdashboard`
--

INSERT INTO `userdashboard` (`id`, `name`, `phonenumber`, `email`, `password`, `address`, `qualification`, `language`, `skill`, `profile`) VALUES
(1, 'Soundar ', '0934254243', 'chinuselvi45@gmail.com', 'EMP028', 'Builders engineering college', 'B.TECH', '2', 'web development', 'dog1.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announce`
--
ALTER TABLE `announce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employeeform`
--
ALTER TABLE `employeeform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hrregform`
--
ALTER TABLE `hrregform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobleave`
--
ALTER TABLE `jobleave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_acceptance`
--
ALTER TABLE `job_acceptance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_vacancy`
--
ALTER TABLE `job_vacancy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaveform`
--
ALTER TABLE `leaveform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotation`
--
ALTER TABLE `quotation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userdashboard`
--
ALTER TABLE `userdashboard`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `announce`
--
ALTER TABLE `announce`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employeeform`
--
ALTER TABLE `employeeform`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `hrregform`
--
ALTER TABLE `hrregform`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `jobleave`
--
ALTER TABLE `jobleave`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `job_acceptance`
--
ALTER TABLE `job_acceptance`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_vacancy`
--
ALTER TABLE `job_vacancy`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `leaveform`
--
ALTER TABLE `leaveform`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quotation`
--
ALTER TABLE `quotation`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `userdashboard`
--
ALTER TABLE `userdashboard`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
