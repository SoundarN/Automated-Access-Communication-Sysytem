#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb,os
cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 <style>
    .card{
        background-color: bisque;
    }
    .dropdown-item{
        background-color: aqua;
    }
 </style>
</head>
<body>

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <img src="./Images py/thriller 2.jpeg"  width="70px" height="40px"><h3>Thiller Software</h3>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ml-auto">

                            <li class="nav-item">
                                <a class="nav-link" href="HOMEPAGE.html">Homepage
                                </a>   
                            </li>
                            <li class="nav-item">
                                <div class="dropdown">
                                <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Login</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="HR.html">HR</a>
                                    <a class="dropdown-item" href="Employee.html">Employee</a>
                                    <a class="dropdown-item" href="Financial Dept.html">Financial Department</a>
                                    <a class="dropdown-item" href="Admin.html">Admin</a>
                                  </div>
                                </div>
                            </li>   
                            </li>
                        </ul>
                    </div>
            </nav><br><br>
            <div class="container">
            <p> <h5><b>The Company was introduced in 2024.</b> <br>
            It's a Reputed Company in the Software Industries. <br> 
            The Employees are free to work here. <br>It has lot of people to work there.</h5></p>
            </div>

            <section id="contact" class="py-5">
                <div class="container">
                    <div class="card">
                    <h2 align="center">Contact Us</h2>
                    <form>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" placeholder="Your Name">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" placeholder="Your Email">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="message">Feedback</label>
                            <textarea class="form-control" id="message" rows="4" placeholder="Your Message"></textarea>
                        </div>
                        <center>
                            <button type="submit" class="btn btn-primary">Submit Feedback</button>
                        </center> 
                    </form>
                </div>
                </div>
            </section><br><br>
            <footer class="bg-dark text-white text-center py-3">
                <p>&copy; 2024 CompanyName. All Rights Reserved.</p>
                <h3>Join with your Team</h3>
                <a href="#">Explore Thriller careers</a>
            </footer>

</body>
</html>
""")