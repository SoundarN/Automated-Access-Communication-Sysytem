#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()
pid=form.getvalue("id")
p="""select * from employeeform where dept='technical' and id='%s' """%(pid)
cur.execute(p)
res=cur.fetchall()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technical Dashboard</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightslategrey;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        
        </style>
</head>
<body>

        <div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Technical_Profile.py?id=%s">Profile</a>
                </li>
                <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Technical_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Technical_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li>
                    <a href="Technical_SalaryExisting.py?id=%s">Salary</a>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leaving Process</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Tec_leaving_new.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Tec_leaving_existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <h2>Role</h2>
                    <li >
                      <a href="Technical_Quotation_Existing.py?id=%s">Quotation</a>  
                    </li>
                    <li >
                      <a href="Tec_Invoice_Existing.py?id=%s">Invoice</a>  
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Project</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Tec_Project_New_APC.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Tec_Project_Existing_APC.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li >
                      <a href="Tec_Announcement.py?id=%s">Announcement</a>  
                    </li>
                    
                """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")

