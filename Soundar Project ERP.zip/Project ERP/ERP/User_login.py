#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login Form</title>
    <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 <style>
    .card{
        background-color: wheat;
    }
    input{
        background-color:cornsilk;
    }
 </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <img src="./Images py/thriller 2.jpeg"  width="70px" height="40px"><h3>Thiller Software</h3>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="Aboutus.py">About Us
                        </a>   
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="User_Register.py">Register
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="HOME.py">Home
                        </a>   
                    </li>
                </ul>
            </div>
    </nav>

    <div class="container">
        <div class="card" style="margin-top: 50px;">
           <div class="card-header">
                 <center><h2>User Login</h2></center>
           </div>
           <div class="card-body">
            <form>
            <div class="form-group">
            <label for="name">Name</label>
            <input type="text" placeholder="Enter your Name" class="form-control" autofocus name="uname">
            </div>
            <div class="form-group">
            <label for="password">Password</label>
            <input type="Password" placeholder="Enter your Password" class="form-control" name="psw">
           </div>
           <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Login" name="sub">
        </form>
</div>
</div>
              </div>
    </div>  
    <footer class="bg-dark text-white text-center py-3" style="margin-top: 250px;">
        <p>&copy; 2024 CompanyName. All Rights Reserved.</p>
        <h3>Join with your Team</h3>
        <a href="#">Explore Thriller careers</a>
    </footer>

</body>
</html>
""")
form = cgi.FieldStorage()
name = form.getvalue("uname")
password = form.getvalue("psw")
submit = form.getvalue("sub")
if submit != None:
    p = """select id from userdashboard where name='%s' and password='%s' """ % (name, password)
    cur.execute(p)
    rec = cur.fetchone()
    if rec != None:
        print("""
        <script>
        alert("login successfully");
        location.href="User_Dashboard.py?id=%s"
        </script>
        """ % rec[0])
    else:
        print("""
        <script>
        alert("user not found")
        </script>
        """)