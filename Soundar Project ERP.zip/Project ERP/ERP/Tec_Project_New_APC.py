#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os,smtplib

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()
pid=form.getvalue("id")
p="""select * from employeeform where dept='technical' and id='%s' """%(pid)
cur.execute(p)
res=cur.fetchall()
eid=""
for i in res:
    eid = i[3]
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technical Project New APC</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightslategrey;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .table{
            margin-left:258px;
        }
        </style>
</head>
<body>

       <div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Technical_Profile.py?id=%s">Profile</a>
                </li>
                <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Technical_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Technical_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li>
                    <a href="Technical_SalaryExisting.py?id=%s">Salary</a>
                    </li>
                    <h2>Role</h2>
                    <li >
                      <a href="Technical_Quotation_Existing.py?id=%s">Quotation</a>  
                    </li>
                    <li >
                      <a href="Tec_Invoice_Existing.py?id=%s">Invoice</a>  
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Project</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Tec_Project_New_APC.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Tec_Project_Existing_APC.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li >
                      <a href="Tec_Announcement.py?id=%s">Announcement</a>  
                    </li>
                """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")

print("""
<table class="table table-bordered">
<tr>
<th>S.no</th>
<th>Customer Name</th>
<th>customer email</th>
<th>project name</th>
<th>documents</th>
<th>date</th>
<th>enddate</th>
<th>employee_name</th>
<th>status</th>
</tr>
""")
a = """select * from project """
cur.execute(a)
re = cur.fetchall()
for a in re:
    print("""
    <form>
    <tr>
        <td><input type="text" name="idname" value='%s' style="border:none;width:20px"></td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td><input type="text" name="employeename" value="%s" style="border:none;"></td>
        <td>
        <select name="prostatus" id="prostatus">
        <option value="Accepted">Accepted</option>
        <option value="processing">Processing</option>
        <option value="completed">Completed</option>
        </select>
        </td>
        <input  type="hidden" name="emid" value="%s" style="border:none">
        <td>
        <input type="submit" class="btn btn-success"  name="sub">
        </td>
        <input type="hidden" name="epid" value="%s" style="border:none">
        <input type="hidden" name="hrmail" value="%s" style="border:none">
      
    </tr>
    </form>
    """ % (a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],eid,pid,a[10]))
empname = form.getvalue("employeename")
hrid = form.getvalue("hrmail")
eeid = form.getvalue("epid")
uid = form.getvalue("idname")
empid = form.getvalue("emid")
status = form.getvalue("prostatus")
submit = form.getvalue("sub")
if submit != None:
    s = """update project set status='%s',employee_mail='%s' where id='%s' """ % (status,empid,uid)
    cur.execute(s)
    con.commit()
    fromadd = "soundar.nsd@gmail.com"
    password = "fwwf jdtt pyxp vtrv"
    toadd = hrid
    subject = "Regarding Project Concept"
    body = "The Project has been Accepted by {}".format(empname)
    msg = """Subject:{}\n\n{}""".format(subject, body)
    server = smtplib.SMTP("smtp.gmail.com:587")
    server.ehlo()
    server.starttls()
    server.login(fromadd, password)
    server.sendmail(fromadd, toadd, msg)
    server.quit()
    print("""
           <script>
           alert("Project is Accepted Successfully");
           location.href="Tec_Project_New_APC.py?id=%s"
           </script>
           """ % (eeid))






