#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb
cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form = cgi.FieldStorage()
pid = form.getvalue("id")
p = """select * from userdashboard where id='%s' """ % (pid)
cur.execute(p)
res = cur.fetchall()
name=""
mail=""
for k in res:
    name=k[1]
    mail=k[3]
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Job New</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightblue;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .card{
        margin-top:100px;
        margin-left:100px;
        
        }
        </style>
</head>
<body>
    <div class="sidebar">
            <ul>
                <li>
                    <a href="User_Profile.py?id=%s">Profile</a>
                </li>
               <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Jobs</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="User_job_new.py?id=%s">New</a>
                                    <a class="dropdown-item" href="User_job_existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li> <a href="HOME.py">Log Out</a></li>
                     </ul>
                    </div>
                    <div class="container">
                    <div class="row">
""" %(pid,pid,pid))


k="""select * from hrregform where id='%s' """%(pid)
cur.execute(k)
rem=cur.fetchall()
hname = ""
hmail = ""
for l in rem:
    hname = l[1]
    hmail = l[3]


p = """select * from job_vacancy """
cur.execute(p)
rek = cur.fetchall()
for j in rek:
    print("""
       <div class="col-sm-4">
            <div class="card" style="width:350px; height:300px;">
                <div class="card-body">
                <h5>Position:%s</h5>
                <h5>Qualification:%s</h5>
                <h5>Experience:%s</h5>
                <h5>Salary:%s</h5>
                <h5>Requirements:%s</h5><br>
                
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="uname" value='%s'>
                    <input type="hidden" name="umail" value='%s'>
                    <input type="hidden" name="pos"   value='%s'>
                    <input type="hidden" name="quali" value='%s'>
                    <input type="hidden" name="sal"   value='%s'>
                    <input type="hidden" name="exp"   value='%s'>
                    <input type="hidden" name="req"   value='%s'>
                    <input type="hidden" name="hname" value='%s'>
                    <input type="hidden" name="hmail" value='%s'>
                   <input type="submit" class="btn btn-success" name="sub" value="Apply">
                </form>
                </div>
                </div>
                </div>
                """%(j[1],j[2],j[3],j[4],j[5],name,mail,j[1],j[2],j[3],j[4],j[5],hname,hmail))
print("""
</div>
</div>
""")


username=form.getvalue("uname")
usermail=form.getvalue("umail")
position=form.getvalue("pos")
qualified=form.getvalue("quali")
salary=form.getvalue("sal")
experience=form.getvalue("exp")
requirements=form.getvalue("req")
hrname=form.getvalue("hname")
hrmail=form.getvalue("hmail")
submit=form.getvalue("sub")
if submit != None:
    g = """insert into job_acceptance(username,usermail,position,qualification,salary,experience,requirements,hrname,hrmail,status) values('%s','%s','%s','%s','%s','%s','%s','%s','%s',"New")""" %(username,usermail,position,qualified,salary,experience,requirements,hrname,hrmail)
    cur.execute(g)
    con.commit()
    print("""
    <script>
        alert("User Form is Accepted Successfully");
        </script>
        """)


