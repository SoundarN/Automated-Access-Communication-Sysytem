#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("connect-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()
pid=form.getvalue("id")
p="""select * from employeeform where dept='marketing' and id='%s' """%(pid)
cur.execute(p)
res=cur.fetchall()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketing Customer View</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    .card{
        background-color:pink;
    }
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
       .sidebar{
        width:250px;
        background-color:lightseagreen;
        
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
            padding:16px;
            margin-left:200px;
        }
        .card{
        width:800px;
        max-width:1000px;
        }
        form{
        padding:50px;
        }
        </style>
</head>
<body>
        <div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Marketing_Profile.py?id=%s">Profile</a>
                </li>
              <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Marketing_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Marketing_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li>
                    <a href="Marketing_SalaryExisting.py?id=%s">Salary</a>
                    </li>
                    <h2>Role</h2>
                    <li><a href="Customer_Store_View.py?id=%s">Customer</a></li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Quotation</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Quotation_New.py?id=%s">New</a>
                                    <a href="Marketing_Quotation_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Invoice</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Invoice_New.py?id=%s">New</a>
                                    <a href="Marketing_Invoice_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li><a href="Marketing_Project_View.py?id=%s">Project</a></li>
                    
                    <li><a href="Marketing_Payment_View.py?id=%s">Payment</a></li>
                    <li><a href="Mar_Announcement.py?id=%s">Announcement</a></li>
                 """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
         <div class="content">
            
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-lg-6">
                    <div class="card">
                    
        <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <b><u><h3 align="center">Customer Form</h3></u></b>
                            <label for="name">Customer Name</label>
                            <input type="text" name="cusname" placeholder="Enter Customer Name"  class="form-control">
                            <label for="address">Customer Address</label>
                            <input type="text" name="cusadd" placeholder="Enter Customer Address"  class="form-control">
                             <label for="mail">Customer Mail</label>
                            <input type="email" name="cusmail" placeholder="Enter Customer Mail"  class="form-control">
                             <label for="number">Customer Number</label>
                            <input type="text" name="cusnum" placeholder="Enter Customer Number"  class="form-control">
                             <label for="idea">Project Idea</label>
                            <input type="text" name="proidea" placeholder="Enter Project Idea "  class="form-control">
                             <label for="amount">Amount</label>
                            <input type="text" name="amount" placeholder="Enter Estimated Amount"  class="form-control"><br>
                            <input type="submit" name="submit" class="btn btn-success">
                            </div>
                            </form>
                            </div>
                            </div>
                            </div>
                            </div>
</body>
</html> """)
if len(form) != 0:
    submit = form.getvalue("submit")
    if submit != None:
        name = form.getvalue("cusname")
        address = form.getvalue("cusadd")
        email = form.getvalue("cusmail")
        phonenumber = form.getvalue("cusnum")
        idea = form.getvalue("proidea")
        amount = form.getvalue("amount")
        a ="""insert into customer(customer_name,customer_address,customer_mail,customer_number,project_idea,estimated_amount)values('%s','%s','%s','%s','%s','%s') """ %(name,address,email,phonenumber,idea,amount)
        cur.execute(a)
        con.commit()
        print("""
        <script>
        alert(" Customer Form is Registered Successfully")
        </script>
        """)

