#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
<title>Employee Existing Password Generate</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
       .sidebar{
        width:200px;
        background-color:pink;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
           .content{
            flex-grow:1;
            text-align:center;
            padding:16px;
            margin-left:260px;
        }
        .table{
            margin-left:255px;
        }
        </style>
</head>
<body>
 <div class="sidebar">
            <h2>Role</h2>
            <ul>
                 <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">HR</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="NewHR.py">New</a>
                                    <a class="dropdown-item" href="HR_Admin_Existing.py">Password Generated</a>
                                    <a class="dropdown-item" href="HR_Pass_View.py">Existing</a>
                                </div>
                        </div>
                    </li>
                
                 <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Employee</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="EmployeeExisting_Password.py">New</a>
                                    <a class="dropdown-item" href="Employee_Exi_Pass_View.py">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="HRLeave_Existing.py">New</a>
                                    <a class="dropdown-item" href="Admin_leave_existing.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Finance Salary</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Finance Salary.py">New</a>
                                    <a class="dropdown-item" href="Admin_Fin_Salary_Existing.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Announcement</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Announcement.py">New</a>
                                    <a class="dropdown-item" href="Admin_Announcement.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leaving Process</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Admin_HR_leaving_new.py">New</a>
                                    <a class="dropdown-item" href="Admin_HR_leaving_existing.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li>
                    <a href="Admin_Employee_Leaving_View.py">Employee Leaving</a>
                </li>
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")
print("""
<table class="table table-bordered ">
<tr>
<th>S.No</th>
<th>Name</th>
<th>email</th>
<th>Phone number</th>
<th>DOB</th>
<th>qualified</th>
<th>street</th>
<th>city</th>
<th>experience</th>
<th>salary</th>
<th>Department</th>
<th>profile</th>
""")
p = """select * from employeeform where status="New" """
cur.execute(p)
res = cur.fetchall()

for i in res:
    user_number = int(i[0])
    user_number += 1
    b = str(user_number)
    random_password = "EMP00" + b
    print("""
    <tr>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
     <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td><img src="./Media_Files/%s" height="100px" width="100px"></td>
    <td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#newmodal%s">Generate Password</button></td>
    </tr>
    """ % (i[0], i[1], i[3], i[6], i[7], i[8], i[9], i[10], i[13], i[14], i[16], i[17], i[0]))
    print("""
    <div class="modal" id="newmodal%s">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Generate Password</h2>
                </div>
                <div class="modal-body">
                    <form>
                     <input type="hidden" class="form-control"  value="%s" readonly name="idd">
                    <label for="">Email</label>
                    <input type="email" class="form-control"  value="%s" readonly name="email">
                    <label for="password">Password</label>
                    <input type="Password" class="form-control" value="%s" readonly name="psw">
                    <br>
                    <input type="submit" class="btn btn-primary" value="Submit" name="sub">
                    </form>
                </div>
                <div class="modal-footer">
                     <button type="button" class="btn btn-danger" data-dismiss="modal">close</button>
                </div>
            </div>
        </div>
    </div>
    """ % (i[0], i[0], i[3], random_password))
form = cgi.FieldStorage()
uid = form.getvalue("idd")
email = form.getvalue("email")
password = form.getvalue("psw")
submit = form.getvalue("sub")
if submit != None:
    ss = """update employeeform set password='%s',status="generated" where id='%s'""" % (password, uid)
    cur.execute(ss)
    con.commit()
    print("""
                <script>
                alert("Form is Registered Successfully")
                </script>
                """)

