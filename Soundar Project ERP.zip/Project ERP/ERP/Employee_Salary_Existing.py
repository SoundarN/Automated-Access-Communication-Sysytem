#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()
pid=form.getvalue("id")
p="""select * from employeeform where dept='financial' and id='%s' """%(pid)
cur.execute(p)
res=cur.fetchall()


print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Salary Existing</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightsteelblue;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .table{
            margin-left:258px;
        }
        </style>
</head>
<body>

      <div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Finance_profile.py?id=%s">Profile</a>
                </li>
               <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Financial_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Financial_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <h2>Role</h2>
                    <ul>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Employee</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Financial_Role_Emp.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Employee_Salary_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">HR</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="hrsalary.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Fin_HR_Salary_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Payment</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Fin_Invoice_New.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Fin_Invoice_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li><a href="Fin_Project_View.py?id=%s">Project</a></li>
                    <li><a href="Fin_Announcement.py?id=%s">Announcement</a></li>
                """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")

print("""
<table class="table table-bordered">
<tr>
<th>S.no</th>
<th>Name</th>
<th>experience</th>
<th>dept</th>
<th>salary</th>
<th>leavedays</th>
<th>salarydate</th>
</tr>
""")
s = """select * from salary where  dept!='HR' and dept!="Financial" """
cur.execute(s)
re = cur.fetchall()
for a in re:
    print("""
        <tr>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
         <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        </tr>
        """ % (a[0], a[1], a[6], a[8], a[10], a[11],a[12]))


