#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("connect-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()
pid=form.getvalue("id")
p="""select * from employeeform where dept='marketing' and id=%s"""%(pid)
cur.execute(p)
res=cur.fetchall()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketing Payment View</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightseagreen;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .table{
            margin-left:258px;
        }
        </style>
</head>
<body>
       <div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Marketing_Profile.py?id=%s">Profile</a>
                </li>
              <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Marketing_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Marketing_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li>
                    <a href="Marketing_SalaryExisting.py?id=%s">Salary</a>
                    </li>
                    <h2>Role</h2>
                    <li><a href="Customer_Store_View.py?id=%s">Customer</a></li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Quotation</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Quotation_New.py?id=%s">New</a>
                                    <a href="Marketing_Quotation_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Invoice</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Invoice_New.py?id=%s">New</a>
                                    <a href="Marketing_Invoice_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li><a href="Marketing_Project_View.py?id=%s">Project</a></li>
                    <li><a href="Marketing_Payment_View.py?id=%s">Payment</a></li>
                    <li><a href="Mar_Announcement.py?id=%s">Announcement</a></li>
                 """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")


print("""
<table class="table table-bordered">
<tr>
<th>S.no</th>
<th>Company Name</th>
<th>Company Address</th>
<th>Company email</th>
<th>phonenumber</th>
<th>invoice no</th>
<th>date</th>
<th>enddate</th>
<th>total payment</th>
<th>Customer Name</th>
<th>Customer address</th>
<th>customer email</th>
<th>project name</th>
<th>project details</th>
<th>documents</th>
<th>payment process</th>
</tr>
""")
s = """select * from invoice where payment_process="paid" or payment_process="unpaid" """
cur.execute(s)
re = cur.fetchall()
for a in re:
    print("""
        <tr>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        </tr>
        """ % (a[0], a[1], a[2], a[3], a[4], a[5],a[6],a[7],a[8],a[9],a[10],a[12],a[13],a[14],a[15],a[18]))



