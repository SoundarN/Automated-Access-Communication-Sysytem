#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form = cgi.FieldStorage()
pid = form.getvalue("id")
p = """select * from employeeform where dept='financial' and id='%s' """ % (pid)
cur.execute(p)
res = cur.fetchall()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Job Leaving Form</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightsteelblue;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        </style>
</head>
<body>

        <div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Finance_profile.py?id=%s">Profile</a>
                </li>
               <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Financial_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Financial_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leaving Process</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Fin_job_leaving_new.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Fin_job_leaving_existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>


                    <h2>Role</h2>
                    <ul>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Employee</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Financial_Role_Emp.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Employee_Salary_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">HR</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="hrsalary.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Fin_HR_Salary_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Payment</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Fin_Invoice_New.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Fin_Invoice_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li><a href="Fin_Project_View.py?id=%s">Project</a></li>
                    <li><a href="Fin_Announcement.py?id=%s">Announcement</a></li>
                """ % (pid, pid, pid, pid, pid, pid, pid, pid, pid, pid, pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")

print("""
            <div class="container">
                <div class="row">
                    <div class="col-sm-6"></div>
                    <div class="col-lg-8">
                        <div class="card" style="margin-top:50px; margin-left:200px; width:200%; padding-left:20px; padding-right:20px;">
                            <form method="post" enctype="multipart/form-data" >
                                <div class="form-group">
                                    <b><u><h3 align="center">Leaving Form</h3></u></b>
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" placeholder="Enter your Name" name="ename">
                                    <label for="dept">Dept</label>
                                    <input type="text" class="form-control" name="dept">

                                    <label for="date">Date</label>
                                    <input type="date" class="form-control" name="date">
                                    <label for="reason">Reason</label>
                                    <input type="text" class="form-control" name="res"><br>
                                <div style="margin-left:350px;">
                                    <input type="submit" class="btn btn-success" name="submit">
                                </div>
                                </div>

                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>                     
        """)

name = form.getvalue("ename")
dept = form.getvalue("dept")
date = form.getvalue("date")
reason = form.getvalue("res")
submit = form.getvalue("submit")
if submit != None:
    d = """insert into jobleave(name,dept,date,reason) values('%s','%s','%s','%s')""" % (name, dept, date, reason)
    cur.execute(d)
    con.commit()
    print("""
        <script>
        alert("Job Leave Form has been Submitted")
        </script>
    """)

