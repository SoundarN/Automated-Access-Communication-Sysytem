#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form = cgi.FieldStorage()
pid = form.getvalue("id")
p = """select * from employeeform where id='%s' """ % (pid)
cur.execute(p)
res = cur.fetchall()

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightseagreen;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        table{
        margin-left:550px;
        margin-left:720px;
        }
        table td {
        padding:10px;
        }
        img{
        margin-left:740px;
        margin-top:100px;
        }
        </style>
</head>
<body>
<div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Marketing_Profile.py?id=%s">Profile</a>
                </li>
              <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Marketing_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Marketing_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li>
                    <a href="Marketing_SalaryExisting.py?id=%s">Salary</a>
                    </li>
                    <h2>Role</h2>
                    <li><a href="Customer_Store_View.py?id=%s">Customer</a></li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Quotation</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Quotation_New.py?id=%s">New</a>
                                    <a href="Marketing_Quotation_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Invoice</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Invoice_New.py?id=%s">New</a>
                                    <a href="Marketing_Invoice_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li><a href="Marketing_Project_View.py?id=%s">Project</a></li>
                    <li><a href="Marketing_Payment_View.py?id=%s">Payment</a></li>
                    <li><a href="Mar_Announcement.py?id=%s">Announcement</a></li>
                 """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")


for i in res:
    print("""
    <div>
    <form>
    <table>
        <tr>
            <img src="./Media_Files/%s " class="img-circle" height="100px" width="100px">
        </tr>
        <tr>
            <th>Name</th>
            <td>%s</td>
        </tr>
        <tr>
            <th>Email</th>
            <td>%s</td>
        </tr> 
        <tr>
            <td><button type="button" class="btn btn-success" data-toggle="modal" data-target="#newmodal%s">Change Password</button></td>
        </tr> 
    </table>
     </form>
    </div>
    """ %(i[17],i[1],i[3],i[0]))
    print("""
            <div class="modal" id="newmodal%s">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Change Password</h2>
                        </div>
                        <div class="modal-body">
                            <form enctype="multipart/form-data" method="post">
                             <input type="hidden" class="form-control" name="idd" value='%s'>

                            <label for="password">New Password</label>
                            <input type="password" class="form-control"  name="newpsw">
                            <label for="password">Conform Password</label>
                            <input type="Password" class="form-control" name="psw">
                              <input type="hidden" class="form-control"  name="oldpsw" value='%s'>
                                <input type="hidden" class="form-control"  name="email" value='%s'><br>
                                 <label for="profile">New Profile</label>
                             <input type="file" name="imgs"><br>
                            <br>
                            <input type="submit" class="btn btn-primary" value="Submit" name="sub">
                            </form>
                        </div>
                        <div class="modal-footer">
                             <button type="button" class="btn btn-danger" data-dismiss="modal">close</button>
                        </div>
                    </div>
                </div>
            </div>
            """ % (i[0], i[0], i[4], i[3]))
if len(form) != None:
    submit = form.getvalue("sub")
    if submit != None:
            uid = form.getvalue("idd")
            npsw = form.getvalue("newpsw")
            cnfpsw = form.getvalue("psw")
            oldpsw = form.getvalue("oldpsw")
            Email = form.getvalue("email")
            profile = form['imgs']

            if oldpsw != npsw:
                if npsw == cnfpsw:
                    if profile.filename:
                        mn = os.path.basename(profile.filename)
                        open("Media_Files/" + mn, "wb").write(profile.file.read())

                        j = """update employeeform set password='%s',profile='%s' where id='%s'""" % (cnfpsw, mn, uid)
                        cur.execute(j)
                        con.commit()
                        print("""
                            <script>
                            alert("Password is Changed Successfully")
                            location.href="HOME.py"
                            </script>
                            """)
                    else:
                        print("""
                            <script>
                            alert("New Password and Confirm Password should be same");
                            location.href="Marketing_Profile.py?id=%s"
                            </script>
                            """ % (uid))
                else:
                    print("""
                            <script>
                            alert("Old Password and New Password Cannot be same");
                            location.href="Marketing_Profile.py?id=%s"
                            </script>
                            """ % (uid))









