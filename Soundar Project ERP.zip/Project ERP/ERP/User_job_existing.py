#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form = cgi.FieldStorage()
pid = form.getvalue("id")
p = """select * from userdashboard where id=%s""" % (pid)
cur.execute(p)
res = cur.fetchall()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Job Existing</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightblue;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .table{
            margin-left:257px;
        }
        </style>
</head>
<body>
    <div class="sidebar">
            <ul>
                <li>
                    <a href="User_Profile.py?id=%s">Profile</a>
                </li>
               <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Jobs</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="User_job_new.py?id=%s">New</a>
                                    <a class="dropdown-item" href="User_job_existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li> <a href="HOME.py">Log Out</a></li>
                     </ul>
                    </div>
</body>
</html>""" %(pid,pid,pid))

print("""
<table class="table table-bordered">
<h1 align="center">Selected Candidate</h1>
<tr>

<th>S.No</th>
<th>Name</th>
<th>email</th>
<th>position</th>
<th>qualification</th>
<th>experience</th>
<th>salary</th>
<th>requirements</th>
<th>hrname</th>
<th>hrmail</th>
<th>suggestion</th>
<th>status</th>
</tr>
""")
z = """select * from job_acceptance where status="selected" """
cur.execute(z)
re = cur.fetchall()
for e in re:
    print("""
        <tr>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
         <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        </tr>
        """ % (e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8],e[9],e[10],e[11]))


print("""
<table class="table table-bordered">
<h1 align="center">Rejected Candidate</h1>
<tr>
<th>S.No</th>
<th>Name</th>
<th>email</th>
<th>position</th>
<th>qualification</th>
<th>experience</th>
<th>salary</th>
<th>requirements</th>
<th>hrname</th>
<th>hrmail</th>
<th>suggestion</th>
<th>status</th>
</tr>
""")
z = """select * from job_acceptance where status="rejected" """
cur.execute(z)
re = cur.fetchall()
for e in re:
    print("""
        <tr>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
         <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        </tr>
        """ % (e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8],e[9],e[10],e[11]))




