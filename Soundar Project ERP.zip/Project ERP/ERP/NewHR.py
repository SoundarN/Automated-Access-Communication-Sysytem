#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html /r/n/r/n")
import pymysql, cgi, cgitb,os
cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NewHR Reg Form</title>
    <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 <style>
    .card{
        background-color:lightgoldenrodyellow;
    }
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
       .sidebar{
        width:250px;
        background-color:pink;
        
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
            padding:16px;
            margin-left:200px;
        }
        .card{
        width:800px;
        max-width:100%;
        }
        form{
        padding:50px;
        }
 </style>
</head>
<body> 
<div class="container">
<div class="sidebar">
            <h2>Role</h2>
            <ul>
                 <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">HR</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="NewHR.py">New</a>
                                    <a class="dropdown-item" href="HR_Admin_Existing.py">Password Generated</a>
                                    <a c;ass="dropdown-item" href="HR_Pass_View.py">Existing</a>
                                </div>
                        </div>
                    </li>
                
                 <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Employee</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="EmployeeExisting_Password.py">New</a>
                                    <a class="dropdown-item" href="Employee_Exi_Pass_View.py">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="HRLeave_Existing.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Admin_leave_existing.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Finance Salary</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Finance Salary.py">New</a>
                                    <a class="dropdown-item" href="Admin_Fin_Salary_Existing.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Announcement</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Announcement.py">New</a>
                                    <a class="dropdown-item" href="Admin_Announcement.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leaving Process</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Admin_HR_leaving_new.py">New</a>
                                    <a class="dropdown-item" href="Admin_HR_leaving_existing.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li>
                    <a href="Admin_Employee_Leaving_View.py">Employee Leaving</a>
                </li>
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
       
    
     <div class="content">
            
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-lg-8">
                    <div class="card">
                    
        <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <b><u><h3 align="center"> HR Register Form</h3></u></b>
                            <label for="Firstname">Firstname</label>
                            <input type="text" placeholder="Enter your firstname" class="form-control" autofocus name="finame">
                            <label for="lastname">Lastname</label>
                            <input type="text" placeholder="Enter your lastname" class="form-control" name="lsname">
                            <label for="email">Email</label>
                            <input type="email" placeholder="Enter your email" class="form-control" required name="email">
                           
                            <label for="Gender">Gender</label>
                            <input type="radio" name="Male" value="Male">
                            <label for="Male"  >Male</label>
                            <input type="radio"  name="Male" value="Female" >
                            <label for="Female"  >Female</label><br>
                            <label for="phonenumber">Phonenumber</label>
                            <input type="text" placeholder="Enter your Phonenumber" class="form-control" name="phonenum">
                            <label for="DOB">Date-of-Birth</label>
                            <input type="date" class="form-control" name="dob">
                            <label for="Qualification">Qualification</label>
                            <select name="Qualification" id="Qualification" class="form-control">
                                <optgroup label="Engg">
                                    <option value="B.TECH">B.TECH</option>
                                    <option value="M.TECH">M.TECH</option>
                                    <option value="BE">BE</option>
                                    <option value="ME">ME</option>
                                </optgroup>
                                <optgroup label="Arts">
                                    <option value="BSC">BSC</option>
                                    <option value="B.FORM">B.FORM</option>
                                    <option value="BBA">BBA</option>
                                    <option value="B.COM">B.COM</option>
                                    <option value="M.COM">M.COM</option>
                                </optgroup>
                            </select>
                            <label for="street">Street</label>
                            <input type="text" placeholder="Enter your Street name" class="form-control" name="street">
                            <label for="city">City</label>
                            <input type="text" placeholder="Enter your city name" class="form-control" name="city">
                            <label for="state">State</label>
                            <input type="text" placeholder="Enter your State name" class="form-control" name="state">
                            <label for="country">Country</label>
                            <input type="text" placeholder="Enter your country name" class="form-control" name="country">
                            <label for="Years of Experience">Years of Experience</label>
                            <input type="number" class="form-control" placeholder="Your Experience" name="exp">
                            <label for="salary expectation">Salary Expectation</label>
                            <input type="number" class="form-control" name="sal">
                            <label for="pincode">Pincode</label>
                            <input type="number" class="form-control" placeholder="Enter your Pincode" name="pin">
                            <label for="Department">Department</label>
                            <select name="Department" id="Department" class="form-control">
                                <optgroup>
                                    <option value="HR">HR</option>
                                    
                                </optgroup>
                            </select><br>
                            <label for="">Upload Profile Photo</label>
                            <input type="file" name="imgs"><br><br>
                            <input type="submit" name="submit" class="btn btn-success">
                            <input type="reset" name="reset" class="btn btn-danger" value="Cancel">
                        </div>
                     </div>
                </div>
            </div>
        </form>
    </div> 
</body>
</html>
""")
form = cgi.FieldStorage()
if len(form) != 0:
    submit = form.getvalue("submit")
    if submit != None:
        firstname = form.getvalue("finame")
        lastname = form.getvalue("lsname")
        email = form.getvalue("email")

        gender = form.getvalue("Male")
        phonenumber = form.getvalue("phonenum")
        dob = form.getvalue("dob")
        qualified = form.getvalue("Qualification")
        Street = form.getvalue("street")
        City = form.getvalue("city")
        State = form.getvalue("state")
        Country = form.getvalue("country")
        experience = form.getvalue("exp")
        salary = form.getvalue("sal")
        pincode = form.getvalue("pin")
        dept = form.getvalue("Department")
        profile = form['imgs']
        if profile.filename:
            fn = os.path.basename(profile.filename)
            open("Media_Files/" + fn, "wb").write(profile.file.read())
            s = """insert into hrregform(firstname,lastname,email,gender,pnumber,dob,qualified,street,city,state,country,experience,salary,pincode,dept,profile,status)values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',"New")""" % (firstname, lastname, email, gender, phonenumber, dob, qualified,Street,City,State,Country, experience, salary, pincode, dept,fn)
            cur.execute(s)
            con.commit()
            print("""
            <script>
            alert("Form is Registered Successfully")
            </script>
            """)

