#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()
pid=form.getvalue("id")
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketing Quotation New</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightseagreen;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .card{
        margin-left:260px;
        width:550px;
        margin:auto;
        background-color:lightgoldenrodyellow ;
        }
        </style>
</head>
<body>
<div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Marketing_Profile.py?id=%s">Profile</a>
                </li>
              <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Marketing_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Marketing_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li>
                    <a href="Marketing_SalaryExisting.py?id=%s">Salary</a>
                    </li>
                    <h2>Role</h2>
                    <li><a href="Customer_Store_View.py?id=%s">Customer</a></li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Quotation</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Quotation_New.py?id=%s">New</a>
                                    <a href="Marketing_Quotation_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Invoice</a>
                                <div class="dropdown-menu">
                                    <a href="Marketing_Invoice_New.py?id=%s">New</a>
                                    <a href="Marketing_Invoice_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li><a href="Marketing_Project_View.py?id=%s">Project</a></li>
                    <li><a href="Marketing_Payment_View.py?id=%s">Payment</a></li>
                    <li><a href="Mar_Announcement.py?id=%s">Announcement</a></li>
                 """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")


print("""
    <div class="card">
    <div class="card-header">
    <h2>Quotation</h2>    </div>
    <div class="card-body">
    <form method="post" enctype="multipart/form-data">
    <div class="form-group">
    <input type="text" name="name" class="form-control" placeholder="Enter Name">
    </div>
    <div class="form-group">
    <input type="text" name="email" class="form-control" placeholder="Enter Email">
    </div>
    <div class="form-group">
    <input type="text" name="comname" class="form-control" placeholder="Enter Company Name">
    </div>
    <div class="form-group">
    <input type="text" name="loc" class="form-control" placeholder="Enter Location">
    </div>
    <div class="form-group">
    <input type="text" name="proname" class="form-control" placeholder="Enter Project Name">
    </div>
    <div class="form-group">
    <input type="text" name="provalue" class="form-control" placeholder="Enter Project Value">
    </div>
    <div class="form-group">
    <input type="text" name="date" class="form-control" placeholder="Enter Time Frame">
    </div>
    <div class="form-group">
    <input type="text" name="protype" class="form-control" placeholder="Enter Project Type">
    <div class="form-group"><br>
    <input type="file" name="imgs">
    </div>
    <input type="submit" name="sub" class="btn btn-success">    
    </form>
    </div>
    </div>
""")
if len(form)!=None:
    submit = form.getvalue("sub")
    if submit != None:
        name = form.getvalue("name")
        mail = form.getvalue("email")
        compname = form.getvalue("comname")
        location = form.getvalue("loc")
        projname = form.getvalue("proname")
        projvalue = form.getvalue("provalue")
        dates = form.getvalue("date")
        projtype = form.getvalue("protype")
        profile = form['imgs']
        if profile.filename:
            fn = os.path.basename(profile.filename)
            open("Media_Files/" + fn, "wb").write(profile.file.read())
            a ="""insert into quotation(name,email,company_name,location,project_name,project_value,date,project_type,documents,status) values('%s','%s','%s','%s','%s','%s','%s','%s','%s',"New")""" %(name,mail,compname,location,projname,projvalue,dates,projtype,fn)
            cur.execute(a)
            con.commit()
            print("""
                <script>
                alert("Quotation Form is Inserted Successfully")
                </script>
                """)


