#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os, smtplib
cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form = cgi.FieldStorage()
pid = form.getvalue("id")

w = """select * from hrregform where id='%s' """ % (pid)
cur.execute(w)
rem = cur.fetchall()
name = ""
eid = ""
for i in rem:
    name = i[1]
    eid = i[0]
print("""
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <title>Employee Leave Existing Form</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <!-- Latest compiled and minified CSS -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

     <!-- jQuery library -->
     <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

     <!-- Popper JS -->
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

     <!-- Latest compiled JavaScript -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:pink;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .table{
            margin-left:257px;
        }
        </style>
    </head>
 <body>
 <div class="sidebar">
        <h2>Personal</h2>
        <ul>
            <li>
                <a href="HR_Profile.py?id=%s">Profile</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HRLeave_Form.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_Leave_View.py?id=%s">Existing</a>
                        </div>
                </div>
            </li>
            <li>
                <a href="HRHR_Salary_Existing.py?id=%s">Salary</a>
            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leaving Job</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HR_Leaving_Job_New.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_Leaving_Job_Existing.py?id=%s">Existing</a>           
                        </div>
                </div>
            </li>
            <h2>Role</h2>
            <li class="nav-item">
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HR_Employee_Leave_New.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_Employee_Leave_Existing.py?id=%s">Existing</a>           
                        </div>
                </div>
            </li>
            """ %(pid,pid,pid,pid,pid,pid,pid,pid))
print("""
            <li class="nav-item" >
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Employee</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="NewEmployee.py?id=%s">New</a>
                            <a class="dropdown-item" href="Employee_Exi_Password_View.py?id=%s">Existing</a>
                        </div>
                </div>
            </li>
            <li class="nav-item" >
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Quotation</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HR_Quotation_New.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_Quotation_Existing.py?id=%s">Existing</a>
                        </div>
                </div>
            </li>
            <li class="nav-item" >
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Invoice</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HR_Invoice_New.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_Invoice_Existing.py?id=%s">Existing</a>
                        </div>
                    </div>
            </li>
            <li class="nav-item" >
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Project</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="Project_HR_View.py?id=%s">New</a>
                            <a class="dropdown-item" href="Project_HR_Existing.py?id=%s">Existing</a>
                        </div>
                    </div>
            </li>
            <li>
                <a href="HR_Announcement.py?id=%s">Announcement</a>
            </li>
            <li class="nav-item" >
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Job Vacancy</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HR_job_new_form.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_job_existing.py?id=%s">Existing</a>
                        </div>
                </div>
            </li>
            <li class="nav-item" >
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Selected</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HR_job_selected_new.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_job_selected_existing.py?id=%s">Existing</a>
                        </div>
                </div>
            </li>
            <li class="nav-item" >
                <div class="dropdown">
                    <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Leaving Process</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="HR_job_leaving_new.py?id=%s">New</a>
                            <a class="dropdown-item" href="HR_job_leaving_existing.py?id=%s">Existing</a>
                        </div>
                </div>
            </li>
            <li> 
                <a href="HOME.py">Log Out</a>
            </li>
        </ul>
    </div>
</body>
</html>""" % (pid, pid, pid, pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))




print("""
<table class="table table-bordered ">
<tr>
<th>S.No</th>
<th>Name</th>
<th>email</th>
<th>dept</th>
<th>date</th>
<th>startdate</th>
<th>enddate</th>
<th>reason</th>
<th>no_of_days</th>
""")
z = """select * from leaveform where dept!='HR' and status="New" """
cur.execute(z)
re = cur.fetchall()
for e in re:
    print("""
        <form>
        <tr>
        <td><input  type="text" name="idname" value="%s" style="border:none;width:20px"></td>
        <td>%s</td>
        <td><input  type="email" name="mail" value="%s" readonly style="border:none;"></td>
        <td>%s</td>
         <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td>%s</td>
        <td><input type="submit" class="btn btn-success" value="Accept" name="accept">
        <input type="submit" class="btn btn-danger" value="Reject" name="reject"></td>
        <input  type="hidden" name="emid" value="%s">
        </tr></form>
        """ % (e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8], eid))
uid = form.getvalue("idname")
empid = form.getvalue("emid")
mailid = form.getvalue("mail")
accept = form.getvalue("accept")
if accept != None:
    s = """update  leaveform set status="Accepted" where id='%s' """ % (uid)
    cur.execute(s)
    con.commit()
    fromadd = "soundar.nsd@gmail.com"
    password = "fwwf jdtt pyxp vtrv"
    toadd = mailid
    subject = "Regarding Leave Request"
    body = "Your Leave Request has been Accepted"
    msg = """Subject:{}\n\n{}""".format(subject, body)
    server = smtplib.SMTP("smtp.gmail.com:587")
    server.ehlo()
    server.starttls()
    server.login(fromadd, password)
    server.sendmail(fromadd, toadd, msg)
    server.quit()
    print("""
       <script>
       alert("Leave is Accepted Successfully");
       location.href="HR_Employee_Leave_Existing.py?id=%s"
       </script>
       """ % (empid))
reject = form.getvalue("reject")
if reject != None:
    sa = """update  leaveform set status="Rejected" where id='%s' """ % (uid)
    cur.execute(sa)
    con.commit()
    fromadd = 'soundar.nsd@gmail.com'
    password = 'slai iznf dzky bbki'
    toadd = mailid
    subject = "Regarding Leave Request"
    body = "Your Leave Request has been Rejected"
    msg = """Subject:{}\n\n{}""".format(subject, body)
    server = smtplib.SMTP("smtp.gmail.com:587")
    server.ehlo()
    server.starttls()
    server.login(fromadd, password)
    server.sendmail(fromadd, toadd, msg)
    server.quit()
    print("""
       <script>
       alert("Leave is Rejected Successfully");
       location.href="HR_Employee_Leave_Existing.py?id=%s"
       </script>
       """ % (empid))









