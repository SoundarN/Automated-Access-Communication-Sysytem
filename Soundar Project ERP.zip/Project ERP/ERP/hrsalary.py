#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form = cgi.FieldStorage()
pid = form.getvalue("id")
dep = form.getvalue("name")
p = """select * from hrregform where dept='HR' and id='%s' """ % (pid)
cur.execute(p)
res = cur.fetchall()
hid = ""
for i in res:
    hid = i[0]

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hr Salary</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
    .sidebar{
        width:250px;
        background-color:lightsteelblue;
        ;
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
        }
        .table{
            margin-left:258px;
        }
        </style>
</head>
<body>

        <div class="sidebar">
            <h2>Personal</h2>
            <ul>
                <li>
                    <a href="Finance_profile.py?id=%s">Profile</a>
                </li>
               <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave Form</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Financial_Leave_Form.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Financial_Leave_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <h2>Role</h2>
                    <ul>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Employee</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Financial_Role_Emp.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Employee_Salary_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">HR</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="hrsalary.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Fin_HR_Salary_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Payment</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Fin_Invoice_New.py?id=%s">New</a>
                                    <a class="dropdown-item" href="Fin_Invoice_Existing.py?id=%s">Existing</a>
                                </div>
                        </div>
                    </li>
                    <li><a href="Fin_Project_View.py?id=%s">Project</a></li>
                    <li><a href="Fin_Announcement.py?id=%s">Announcement</a></li>
                """ %(pid,pid,pid,pid,pid,pid,pid,pid,pid,pid,pid))
print("""
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>
</body>
</html>""")

print("""
<table class="table table-bordered ">
<tr>
<th>s.no</th>
<th>firstname</th>
<th>email</th>
<th>phonenumber</th>
<th>qualified</th>
<th>experience</th>
<th>salary</th>
<th>dept</th>
<th>profile</th>

""")
a = """select * from hrregform where dept="HR" """
cur.execute(a)
rek = cur.fetchall()
for j in rek:
    name = j[1]
    dept = j[16]

    print("""
    <tr>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td>%s</td>
    <td><img src="./Media_Files/%s" height="100px" width="100px"></td>
    <td><button type="button" class="btn btn-success"  data-toggle="modal" data-target="#newmodal%s">Credit Salary</button></td>
    </tr>
    """ % (j[0],j[1], j[3], j[6], j[8], j[13], j[14], j[16], j[17], j[0]))
    print("""
    <div class="modal" id="newmodal%s">
        <div class="modal-dialog dialog-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h2>Credit Salary</h2>
                </div>
                <div class="modal-body">
                <form method="post">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" name="fname" value='%s'>
                    <label for="experience">Experience</label>
                    <input type="text" class="form-control" name="exp" value='%s'>
                    <input type="hidden" class="form-control" name="mail" value='%s'>
                    <input type="hidden" class="form-control" name="phnum" value='%s'>

                    <input type="hidden" class="form-control" name="qualified" value='%s'>

                    <input type="hidden" class="form-control" name="cities" value='%s'>

                    <input type="hidden" class="form-control" name="salaries" value='%s'>

                    <input type="hidden" class="form-control" name="dept" value='%s'>
                    <input type="hidden" class="form-control" name="prof" value='%s'>


                    """ % (j[0], j[1], j[13], j[3], j[6], j[8], j[10], j[14], j[16], j[17]))
    b = """select sum(no_of_days) from leaveform where name='%s' and dept='%s' """ % (name, dept)
    cur.execute(b)
    r = cur.fetchone()
    num = str(r[0])
    from datetime import datetime

    cs = datetime.now()
    vs = cs.strftime("%d-%m-%Y")
    print("""

                    <label for="noofdays">No_of_Days</label>
                    <input type="text" class="form-control" name="day" value='%s' readonly>
                    <br>
                     <label for="tdate">Date</label>
                    <input type="text" class="form-control" name="tdate" value='%s' readonly>
                    <br>
                     <label for="noofdays">Salary</label>
                    <input type="text" class="form-control" name="salary" >
                    <br>
                    <input type="submit" class="btn btn-primary" value="Credit Salary" name="sub">
                    </form>
                    </div>
                </div>
            </div>
        </div>
        """ % (num, vs))

names = form.getvalue("fname")
exps = form.getvalue("exp")
days = form.getvalue("day")
mal = form.getvalue("mail")
phonenumber = form.getvalue("phnum")
qualification = form.getvalue("qualified")
city = form.getvalue("cities")
salary_exp = form.getvalue("salaries")
department = form.getvalue("dept")
profile = form.getvalue("prof")
todaydate = form.getvalue("tdate")
salamount = form.getvalue("salary")
submit = form.getvalue("sub")
if submit != None:
    aa = """insert into salary(firstname,experience,leavedays,email,phonenumber,qualification,city,salary_exp,dept,profile,salary,salarydate) values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')""" % (
    names, exps, days, mal, phonenumber, qualification, city, salary_exp, department, profile, salamount, todaydate)
    cur.execute(aa)
    con.commit()
    print("""
    <script>
    alert("salary is Credited Successfully");
    </script>
    """)





