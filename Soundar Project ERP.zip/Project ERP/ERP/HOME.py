#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb,os
cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
 <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 <style>
   .dropdown-item{
    background-color: lightblue;
   }
 </style>

</head>
<body>
    <div class="container-fluid">

                        <nav class="navbar navbar-expand-lg navbar-light bg-light">
                            <img src="./Images py/thriller 2.jpeg"  width="70px" height="40px"><h3>Thiller Software</h3>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                                <div class="collapse navbar-collapse" id="navbarNav">
                                    <ul class="navbar-nav ml-auto">

                                        <li class="nav-item">
                                            <a class="nav-link" href="Aboutus.py">About Us
                                            </a>   


                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="User_Register.py">Register
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <div class="dropdown">
                                                <a href="" class="nav-link dropdown-toggle" style="width:150px"  data-toggle="dropdown">Login</a>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="HRlogin.py">HR</a>
                                                        <a class="dropdown-item" href="Technical_Login.py">Technical</a>
                                                        <a class="dropdown-item" href="Financial_Login.py">Financial</a>
                                                        <a class="dropdown-item" href="Marketing_Login.py">Marketing </a>
                                                        <a class="dropdown-item" href="ADMIN_login.py">Admin</a>
                                                         <a class="dropdown-item" href="User_login.py">User</a>                                              
                                                 </div>
                                            </div>
                                        </li>
                                        
                                        
                                    </ul>
                                </div>
                        </nav>
            <header class="hero bg-primary text-white text-center py-5">
                <div class="container">
                    <h1 class="display-4">Welcome to CompanyName</h1>
                    <p class="lead">We offer amazing services to help your business grow.</p>
                    <a href="#" class="btn btn-light btn-lg">Learn More</a>
                </div>
            </header>       

    <section id="about" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2>About Us</h2>
                    <p>Focus  on your technical skills, expertise in programming languages and software development frameworks, and your experience in software development.</p>
                </div>
                <div class="col-lg-6">
                    <img src="./Images py/log 3.jpeg"  alt="About Us" width="350px" height="200px">
                </div>
            </div>
        </div>
    </section>
    <div class="container">
    <div id="demo" class="carousel slide" data-ride="carousel">
        <ul class="carousel-indicators">
          <li data-target="#demo" data-slide-to="0" class="active"></li>
          <li data-target="#demo" data-slide-to="1"></li>
          <li data-target="#demo" data-slide-to="2"></li>
        </ul>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="./Images py/ho bg.jpeg"  width="1100" height="500">
          </div>
          <div class="carousel-item">
            <img src="./Images py/ho bg5.jpeg"  width="1100" height="500">
          </div>
          <div class="carousel-item">
            <img src="./Images py/ho bg6.jpg" width="1100" height="500">
          </div>
        </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
          <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
          <span class="carousel-control-next-icon"></span>
        </a>
      </div>
    </div><br><br>
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2024 CompanyName. All Rights Reserved.</p>
        <h3>Join with your Team</h3>
        <a href="#">Explore Thriller careers</a>
    </footer>


    </div>
</body>
</html>
""")