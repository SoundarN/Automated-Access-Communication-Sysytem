#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("connect-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb,smtplib
cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()

print("""
<html>
<head>
<body>
<form method="post">
<label>MAIL</label>
<input type="text" name="email">
<input type="submit" name="sub">
</form>
</body>
</head>
</html>

""")
Email=form.getvalue("email")
Submit=form.getvalue("sub")
if Submit!=None:
    q="""select * from employeeform where email='%s' """%(Email)
    cur.execute(q)
    rem=cur.fetchall()
    for i in rem:
        Name=i[1]
        Password=i[4]

        fromadd = 'soundar19soundar@gmail.com'
        password = 'mtvf evep futm iqnq'
        toadd = Email
        subject = "Regarding Leave Request"
        body = "Your Leave Request has been Accepted"
        msg = """Subject:{}\n\n{}""".format(subject, body)
        server = smtplib.SMTP("smtp.gmail.com:587")
        server.ehlo()
        server.starttls()
        server.login(fromadd, password)
        server.sendmail(fromadd, toadd, msg)
        server.quit()
        print("""
               <script>
               alert("Leave is Accepted Successfully");
               location.href="HR_Employee_Leave_Existing.py"
               </script>
               """)