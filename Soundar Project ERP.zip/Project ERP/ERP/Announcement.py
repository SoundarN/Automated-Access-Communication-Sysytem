#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
form=cgi.FieldStorage()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcement</title>
     <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    .card{
        background-color:skyblue;
    }
    body,
    ul{
        margin:0;
        padding:0;
    }
    .container{
        display:flex;
        }
       .sidebar{
        width:250px;
        background-color:pink;
        
        overflow-y:auto;
        height:100vh;
        position:fixed;
        top:0;
        left:0;
        }
        .sidebar h2{
            color:white;
            text-align:center;
            padding:10px;
            margin:0;
        }
        .sidebar ul{
            list-style:none;
            padding:0;
        }
        .sidebar ul li{
            padding-top:10px;
            text-align:left;
        }
        .sidebar ul li a{
            color:black;
            text-decoration:none;
            display:block;
            transition:background-color 0.3s,color 0.3s;
            font-size: 20px;
        }
        .sidebar ul li a:hover{
            background-color: ;
            color: red;
        }
        .sidebar ul li a dropdown-item{
            background-color:;
            text-color:black;
            }
        .dropdown-content{
            display:none;
            padding-left:20px;
            font-size:15px;
        }
        .sidebar ul li:hover.dropdown-content{
            display:block;
        }
        .content{
            flex-grow:1;
            text-align:center;
            padding:16px;
            margin-left:200px;
        }
        .card{
        width:800px;
        max-width:1000px;
        }
        form{
        padding:50px;
        }
        </style>
</head>
<body>

        <div class="sidebar">
            <h2>Role</h2>
            <ul>
                 <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">HR</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="NewHR.py">New</a>
                                    <a class="dropdown-item" href="HR_Admin_Existing.py">Password Generated</a>
                                    <a class="dropdown-item" href="HR_Pass_View.py">Existing</a>
                                </div>
                        </div>
                    </li>

                 <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Employee</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="EmployeeExisting_Password.py">New</a>
                                    <a class="dropdown-item" href="Employee_Exi_Pass_View.py">Existing</a>
                                </div>
                        </div>
                    </li>
                     <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leave</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="HRLeave_Existing.py">New</a>
                                    <a class="dropdown-item" href="Admin_leave_existing.py">Existing</a>

                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Finance Salary</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Finance Salary.py">New</a>
                                    <a class="dropdown-item" href="Admin_Fin_Salary_Existing.py">Existing</a>

                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Announcement</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Announcement.py">New</a>
                                    <a class="dropdown-item" href="Admin_Announcement.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a href="" class="nav-link dropdown-toggle" style="width:150px;margin-left:-10px"  data-toggle="dropdown">Leaving Process</a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="Admin_HR_leaving_new.py">New</a>
                                    <a class="dropdown-item" href="Admin_HR_leaving_existing.py">Existing</a>
                                    
                                </div>
                        </div>
                    </li>
                    <li>
                    <a href="Admin_Employee_Leaving_View.py">Employee Leaving</a>
                    <li> <a href="HOME.py">Log Out</a></li>
            </ul>
        </div>""")
from datetime import datetime

cs = datetime.now()
vs = cs.strftime("%d-%m-%Y")
print("""
        <div class="content">
            
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-lg-6">
                    <div class="card">
                    
        <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <b><u><h3 align="center">Announcement</h3></u></b>
                            <label for="date">Date</label>
                            <input type="text" class="form-control"  name="dates" value="%s">
                            <label for="annocument-date">Announcement Date</label>
                            <input type="date" name="ann-date" placeholder="Enter Announcement Date" class="form-control">
                            <label for="meeting-date">Meeting Date</label>
                            <input type="date" name="mee-date" placeholder="Enter Meeting Date" class="form-control">
                            <label for="time">Meeting Time</label>
                            <input type="text" name="mee-time" placeholder="Enter Meeting Time" class="form-control">
                            <label for="about">Meeting About</label>
                            <input type="text" name="mee-about" placeholder="Enter about meeting" class="form-control">
                             <label for="dept">Dept</label>
                            <select name="mee-dept" id="mee-dept" class="form-control">
                                <optgroup>
                                    <option value="all">All</option>
                                    <option value="hr">HR</option>
                                    <option value="technical">Technical</option>
                                    <option value="marketing">Marketing</option>
                                    <option value="financial">Financial</option>
                                </optgroup>
                            </select>
                            <label for="place">Meeting Hall</label>
                            <input type="text" name="mee-hall" placeholder="Enter Meeting Hall" class="form-control"><br>
                            <input type="submit" name="submit" class="btn btn-success">
                            </div>
                            </form>
                            </div>
                            </div>
                            </div>
                            </div>
</body>
</html>"""%(vs))
if len(form) != 0:
    submit = form.getvalue("submit")
    if submit != None:
        date = form.getvalue("dates")
        announcement_date = form.getvalue("ann-date")
        meeting_date = form.getvalue("mee-date")
        meeting_time = form.getvalue("mee-time")
        meeting_about = form.getvalue("mee-about")
        dept = form.getvalue("mee-dept")
        meeting_area = form.getvalue("mee-hall")
        a ="""insert into announcement(date,announcement_date,meeting_date,meeting_time,meeting_about,dept,meeting_area,status)values('%s','%s','%s','%s','%s','%s','%s',"New") """ %(date,announcement_date,meeting_date,meeting_time,meeting_about,dept,meeting_area)
        cur.execute(a)
        con.commit()
        print("""
        <script>
        alert(" Announcement  Form is Announced Successfully")
        </script>
        """)

