#!C:/Users/admin/AppData/Local/Programs/Python/Python311/python.exe
print("content-type:text/html \r\n\r\n")
import pymysql, cgi, cgitb, os

cgitb.enable()
con = pymysql.connect(host="localhost", user="root", password="", database="data2")
cur = con.cursor()
print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Register Form</title>
    <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

 <!-- jQuery library -->
 <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

 <!-- Popper JS -->
 <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

 <!-- Latest compiled JavaScript -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 <style>
    .card{
        background-color: wheat;
    }
    input{
        background-color:cornsilk;
    }
 </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <img src="./Images py/thriller 2.jpeg"  width="70px" height="40px"><h3>Thiller Software</h3>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="Aboutus.py">About Us
                        </a>   
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="User_Register.py">Register
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="HOME.py">Home
                        </a>   
                    </li>
                </ul>
            </div>
    </nav>

    <div class="container">
        <div class="card" style="margin-top: 50px;">
           <div class="card-header">
                 <center><h2>User Register Form</h2></center>
           </div>
           
           <div class="card-body">
            <form method="post" enctype="multipart/form-data">
            
            <div class="form-group">
            <label for="name">Name</label>
            <input type="text" placeholder="Enter your Username" class="form-control" name="uname" autofocus>
            </div>
            
            <div class="form-group">
            <label for="phonenumber">Phonenumber</label>
            <input type="text" placeholder="Enter your Phonenumber" class="form-control" name="phnum">
           </div>
           
           <div class="form-group">
            <label for="email">Email</label>
            <input type="email" placeholder="Enter your Email" class="form-control" name="mail">
           </div>
           <div class="form-group">
            <label for="password">Password</label>
            <input type="password" placeholder="Enter your Password" class="form-control" name="psw">
           </div>
           <div class="form-group">
            <label for="address">Address</label>
            <input type="text" placeholder="Enter your Address" class="form-control" name="add">
           </div>
           
           <div class="form-group">
            <label for="qualification">Qualification</label>
            <input type="text" placeholder="Enter your Qualification" class="form-control" name="qualified">
           </div>
           
           <div class="form-group">
            <label for="language">Languages Known</label>
            <input type="text" placeholder="Enter your language known" class="form-control" name="lng">
           </div>
           
           <div class="form-group">
            <label for="skill">Skills</label>
            <input type="text" placeholder="Enter your Skills" class="form-control" name="skl">
           </div>
           
           <div class="form-group">
            <label for="">Upload Profile Photo</label>
            <input type="file" name="imgs">
           </div>
           
            <input type="submit" class="btn btn-primary"  name="sub" value="Register">
        </form>
            </div>
        </div>
    </div>
</body>
</html>""")
form = cgi.FieldStorage()
if len(form) != 0:
    submit=form.getvalue("sub")
    if submit != None:
        name = form.getvalue("uname")
        phonenumber = form.getvalue("phnum")
        mail=form.getvalue("mail")
        password=form.getvalue("psw")
        address=form.getvalue("add")
        qualification=form.getvalue("qualified")
        languages=form.getvalue("lng")
        skills=form.getvalue("skl")
        profile=form['imgs']
        if profile.filename:
            an = os.path.basename(profile.filename)
            open("Media_Files/" + an, "wb").write(profile.file.read())
            j ="""insert into userdashboard(name,phonenumber,email,password,address,qualification,language,skill,profile) values('%s','%s','%s','%s','%s','%s','%s','%s','%s')""" %(name,phonenumber,mail,password,address,qualification,languages,skills,an)
            cur.execute(j)
            con.commit()
            print("""
                <script>
                alert(" Register Form is Registered Successfully")
                </script>
                """)